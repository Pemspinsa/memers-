module Lib where


-- Proven by a fair dice roll.
-- Take that, pure functions!
random :: Int
random = 4
